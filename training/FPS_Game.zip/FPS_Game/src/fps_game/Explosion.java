/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fps_game;

/**
 *
 * @author 행복
 */
public class Explosion { //여려개의 폭발 이미지를 그리기 위해 클래스를 추가하여 객체관리
    int x;
    int y;
    int ex_cnt; //이미지를 순차적으로 그리기 위한 카운터
    int damage; //이미지 종류를 구분하기 위한 변수값
    
    Explosion(int x, int y){
        this.x =x;
        this.y =y;       
    }
    public void effect(){
        ex_cnt++; //해당 메소드를 호출시 카운터를 +1시킨다.
    }
}
