/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fps_game;

/**
 *
 * @author 행복
 */
public class Enemy{ //적 위치파악및 이동을 위한 클래스
    int x;
    int y;
    int speed;
    static boolean direction;
    Enemy(int x, int y,int speed){
        this.x = x;
        this.y = y;
        this.speed = speed;
    }
    public void move(int cnt){
        x-=speed; //적 이동속도만큼 이동
        if(cnt % 30 == 0){
            if(direction) direction = false;
            else direction = true;            
        }
        if(direction){
            y+=speed*0.46;
        }
        else{
            y-=speed*0.53;
        }
    }
    public void move2(int cnt){
         x-=speed; //적 이동속도만큼 이동
        if(cnt % 10 == 0){
            if(direction) direction = false;
            else direction = true;            
        }
        if(direction){
            y-=speed*0.62;
        }
        else{
            y+=speed*0.65;
        }
    }
}
