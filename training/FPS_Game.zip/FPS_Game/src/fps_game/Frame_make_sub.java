/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fps_game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author 행복
 */
class Frame_make_sub extends JFrame implements KeyListener, Runnable{
    //키보드이벤트처리 : KeyListener, 스레드 돌리기: Runnable
    int f_width;
    int f_height;
    int x,y; //캐릭좌표변수
    
   
    
    boolean KeyUP = false;
    boolean KeyDown = false;
    boolean KeyLeft = false;
    boolean KeyRight = false;
    boolean KeySpace = false; //미사일 발사를 위한 키보드 스페이스키 입력 추가
    
    int cnt; //각종 타이밍 조절을 위한 무한 루프를 카운터할 변수
    
    int player_Speed;
    int missile_Speed;
    int fire_Speed;
    int enemy_Speed;
    int player_Status = 0; //유저캐릭터 상태체크 변수. 평상시 : 0, 미사일발사: 1, 충돌 : 2
    int game_Score; //게임 점수 계산
    int player_Hitpoint; //플레이어 케릭터의 체력
    
    int e_w = 85, e_h = 85; //적 이미지의 크기값을 받을 변수
    int m_w = 25, m_h = 25; //미사일 이미지의 크기값을 받을 변수
    
    Thread th; //쓰레드 생성
    
    
    Toolkit tk = Toolkit.getDefaultToolkit(); // 이미지를 불러오기 위한 툴킷
    Image me_img;
    Image resized_me_img;
    Image Missile_img; // 미사일 이미지 변수
    Image resised_Missile_img;
    Image Enemy_img; //적 이미지를 받아들일 변수
    Image resized_Enemy_img; 
    Image Effect;
    Image resized_Effect_img;
    Image gameOver;
    Image resized_gameOver;
    Image BackGround_img;//배경이미지
    Image resized_BackGround_img;
    Image Missile2_img;
    Image resized_Missile2_img;
 
    
    ArrayList Missile_List = new ArrayList(); //다수의 미사일을 관리하기 위한 배열
    ArrayList Enemy_List = new ArrayList(); //다수의 적을 관리하기위한 배열
    ArrayList Explosion_List = new ArrayList(); //다수의 폭발 이펙트를 처리하기 위한 배열
    
    //더블 버퍼링용
    Image buffImage; //빈 이미지
    Graphics buffg; //그림그릴 도구 클래스
    
    Missile ms; //미사일 클래스 접근 키
    Enemy en;
    Explosion ex; //폭발 이펙트용 클래스 접근 키
    
    boolean cc=false;
    
    Frame_make_sub(){
        init(); //나중에 프레임에 들어갈 컴포넌트 세팅 메소드
        start(); //나중을 위한 기본적인 시작 명령 처리 부분
        
        setTitle("주인공이 된 유령몬");
        setSize(f_width, f_height);
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        //프레임이 윈도우에 표시될 때 위치를 세팅하기 위해 현재 모니터의 해상도값을 받아옴
        
        int f_xpos = (int)(screen.getWidth() / 2-f_width / 2);
        int f_ypos = (int)(screen.getHeight()/ 2-f_height / 2);
        //프레임을 화면의 정 중앙에 위치시키기 위해 좌표값을 계산함.
        
        setLocation(f_xpos,f_ypos); //프레임을 화면에 보이게 배치
        setResizable(false); //프레임의 크기를 임의로 변경 못하게 설정
        setVisible(true); //프레임을 눈에 보이게 띄움
    }
    
    public void init(){
        x = 100; //캐릭터 최초의 좌표
        y = 100;
        f_width = 800;
        f_height = 600;
        
        
        me_img = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\주인공.png"); 
        //주인공 이미지 불러오기
        resized_me_img = me_img.getScaledInstance(100, 100, Image.SCALE_SMOOTH);//속도보다 부드러움
        //주인공 이미지 사이즈 조정
        Missile_img = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\star.png"); 
        //미사일 이미지를 불러온다
        resised_Missile_img = Missile_img.getScaledInstance(m_w, m_h, Image.SCALE_SMOOTH);
        //미사일 이미지 사이즈 조정
        Enemy_img = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\monster.png");
        resized_Enemy_img = Enemy_img.getScaledInstance(e_w, e_h, Image.SCALE_SMOOTH);
        Effect = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\이펙트.png");
        BackGround_img = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\밤하늘.png");
        resized_BackGround_img = BackGround_img.getScaledInstance(f_width, f_height, Image.SCALE_SMOOTH);
        resized_Effect_img = Effect.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        gameOver = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\game_over.png");
        resized_gameOver = gameOver.getScaledInstance(f_width, f_height, Image.SCALE_SMOOTH);
        Missile2_img = tk.getImage("C:\\Users\\행복\\Documents\\NetBeansProjects\\FPS_Game\\src\\fps_game\\이펙트.png");
        resized_Missile2_img = Missile2_img.getScaledInstance(55, 55, Image.SCALE_SMOOTH);
        
        
        game_Score = 0;
        player_Hitpoint = 5; //최소 플레이어 체력
        player_Speed = 5;//유저캐릭터 움직이는 속도 설정
        missile_Speed = 11; //미사일 움직일 속도 설정
        fire_Speed = 5; //미사일 연사 속도 설정
        enemy_Speed = 7; //적이 날아오는 속도 설정
       
    }
    
    public void start(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //프로그램 오른쪽 위에 X 버튼을 눌렀을때 프로그램이 정상종료하게 만듦.
        
        addKeyListener(this);
        th = new Thread(this);
        th.start(); //start메소드가 run 메소드를 호출
    }
    
    public void run(){
        try{
            while(true){                
                if(player_Hitpoint ==0) { //목숨이 0되면 멈춤
                    th.stop();
                }
                //Process는 결국 x,y값을 처리해 주는것
                keyProcess(); //키보드 입력처리를 하여 x,y갱신
                Enemy_Process(); //적 움직임 처리 메소드 실행
                MissileProcess();// 미사일 처리 메소드 실행
               
                               
                //프로세스를 처리해서 각 요소들의 위치값을 조정하고 paint메소드 사용
                repaint(); // 강제로 paint() 메소드를 한 번 더 호출하고 싶을 때 사용
                if(Explosion_List.size()!=0) Thread.sleep(200);
                Thread.sleep(20); //20미리세컨드 휴식 후 돌리기
                ExplosionProcess();
                cnt++; //의도적으로 입력을 조절하기 위한 변수
            }
        }
        catch(Exception e){}
    }
    
    public void MissileProcess(){ // 미사일 처리 메소드
        //좌표,객체 생성
        if(KeySpace){ //스페이스키 상태가 True이고, cnt가 특정 값을 가지면(스페이스바를 계속 누르고 있으면 미사일이 너무 많이 생기므로)
            if((cnt % fire_Speed) == 0){
                ms = new Missile(x,y,missile_Speed,0); //미사일의 생성 위치 = 주인공의 위치. y좌표는 미사일이 없어질때까지 변경할 필요가 없음
                Missile_List.add(ms); //해당 미사일 추가 **어레이리스트에 값을 추가할때는 해당 데이터의 주소값을 넘겨주면 된다. 
            }                     
        }
        
        for(int i=0 ; i<Missile_List.size() ; ++i){
            ms = (Missile)Missile_List.get(i); //미사일 리스트에 있는 모든 미사일을 일정 간격씩 이동.
            
            //이동처리
            if(ms.who == 0) ms.move();
            else ms.move2();
            
            //삭제처리
            if(ms.x >f_width - 20){
                Missile_List.remove(i);
            }
            
            if(Crash(x,y,ms.x,ms.y,100,100,55,1) && ms.who ==1){
                player_Hitpoint--;
                ex = new Explosion(x,y);
                Explosion_List.add(ex);
                Missile_List.remove(i);
            }
            
            for(int j=0 ; j<Enemy_List.size() ; ++j){ //미사일 하나 하나에 대해 적과 충돌하는지 확인
                en = (Enemy) Enemy_List.get(j);
                if(Crash(ms.x,ms.y,en.x,en.y,m_w,m_h,e_w,e_h) && ms.who ==0){ //미사일과 적 객체를 하나하나 판변하여 접촉했을 시 미사일과 적을 화면에서 지움
                    // 판별엔 Crach메소드에서 계산하는 방식을 씀               
                    Missile_List.remove(i);
                    Enemy_List.remove(j);
            
                    game_Score += 10; //게임점수 +10점               
                }
            }
            
           
        }        
    }
    
    public void ExplosionProcess(){
        for(int i=0 ; i<Explosion_List.size(); ++i){
            ex = (Explosion)(Explosion_List.get(i));
            int size = Enemy_List.size();
            for(int t=0 ; t<size ; ++t){
                en = (Enemy)(Enemy_List.get(t));
                if(ex.x != en.x && ex.y != en.y){
                    if(t==size-1) Explosion_List.remove(i);
                    continue;
                }
                else{
                    break;
                }
                
                
            }
        }
    }
    
    public void Enemy_Process(){ // 적 위치 변경
        for(int i=0 ; i< Enemy_List.size() ; ++i){
            en = (Enemy)(Enemy_List.get(i)); //배열에 적이 생성되었을 때 해당되는 적을 판별
            if(i%3 == 0) en.move(cnt);
            else en.move2(cnt);
            if(en.x < 0 || (en.y <0 || en.y>f_height-50)){ //적의 좌표가 화면 밖으로 넘어가면
                Enemy_List.remove(i); //해당 적을 배열에서 삭제
                
            }
            
            if(Crash(x+50,y+50,en.x,en.y,1,1,10,e_h)){ //주인공이랑 적이 부딪치는 경우
                player_Hitpoint -=1;                
                Enemy_List.remove(i); //적이 없어지면서 주인공의 체력을 깎아먹음
                ex = new Explosion(x,y);   
                Explosion_List.add(ex);
            }
            if(cnt%50 == 0){
                ms = new Missile(en.x,en.y, missile_Speed,1);
                Missile_List.add(ms);
            }
        }
        
        if(cnt %100 == 0){ //루프 카운트 300회 마다
            en = new Enemy(f_width + 30,300,enemy_Speed);
            Enemy_List.add(en); //각 좌표로 적을 생성한 후 배열에 추가한다.
        }
        if(cnt %200 == 0){
            en = new Enemy(f_width + 500,470,enemy_Speed);
            Enemy_List.add(en); //각 좌표로 적을 생성한 후 배열에 추가한다.
        }
        if(cnt %150 == 0){
            en = new Enemy(f_width + 100,500,enemy_Speed);
            Enemy_List.add(en); //각 좌표로 적을 생성한 후 배열에 추가한다.
        }
        if(cnt %230 == 0){
            en = new Enemy(f_width + 400,320,enemy_Speed);
            Enemy_List.add(en); //각 좌표로 적을 생성한 후 배열에 추가한다.
        }
        if(cnt %190 == 0){
            en = new Enemy(f_width + 50,460,enemy_Speed);
            Enemy_List.add(en); //각 좌표로 적을 생성한 후 배열에 추가한다.
        }
        if(cnt %190 == 0){
            en = new Enemy(f_width + 700,520,enemy_Speed);
            Enemy_List.add(en); //각 좌표로 적을 생성한 후 배열에 추가한다.
        }
            
    }
    
    public boolean Crash(int x1, int y1, int x2, int y2, int w1, int h1, int w2, int h2){
        //충돌 판정을 위한 새로운 Crash 메소드.
        //판정을 위해 충돌할 두 사각 이미지 좌표 및 넓이, 높이값을 받아들임
        //여기서 이미지의 높이, 넓이 값을 계산하기 위해 밑에 보면
        //이미지 크기 계산용 메소드를 또 추가함.
        boolean check = false;
        
        if(Math.abs((x1+w1/2)-(x2+w2/2)) < (w2/2 + w1/2) && Math.abs((y1+h1/2)-(y2+h2/2)) < (h2/2+h1/2)){
            //충돌 계산식. 사각형 두개의 거리 및 겹치는 여부를 확인하는 방식. 좀 복잡함
            check = true;
        }else{check = false;}
        
        return check;
    }
   
   //여기서 Graphics는 본화면의 그래픽을 뜻함.
   public void paint(Graphics g){ //창의 최소화,최대화될때 자동 호출됨. 화면이 가려졌다 다시보여질때
       buffImage = createImage(f_width, f_height); //더블 버퍼링 크기를 화면 크기와 같게 설정
       buffg = buffImage.getGraphics(); //버퍼의 그래픽 객체를 얻기. 빈칸.
       
       Update(g);
   }
   
   public void Update(Graphics g){
       //다 메모리상의 buffImage에 그리는것
       Draw_Background();
       Draw_Char(); //실제로 그려진 그림을 가져온다      
       Draw_Enemy(); //그려진 적 이미지 가져오기      
       Draw_Missile(); //그려진 미사일 가져와 실행
       Draw_Effect();
       Draw_Status_Text();        

       //이 함수가 찐 그리는 함수. buffImage에 완성된 그림을 화면 그래픽에 그린다.
       g.drawImage(buffImage, 0, 0, this); 
   }
   public void Draw_Background(){
       buffg.clearRect(0, 0, f_width, f_height); //버퍼지우고 그림 그리기   
       if(player_Hitpoint == 0){
           buffg.drawImage(resized_gameOver, 0, 0, this);
           return;
       }
       buffg.drawImage(resized_BackGround_img, 0, 0, this);
       //bx를 0에서 1만큼 계속 줄이므로 배경이미지의 x좌표는 계속 좌측으로 이동한다. 그러므로 전체 배경은 천천히 좌측으로 움직이게 된다.      
   }
   public void Draw_Effect(){
       if(player_Hitpoint == 0){
           return;
       }
            for(int i=0 ; i<Explosion_List.size() ; ++i){
                ex = (Explosion)Explosion_List.get(i);                
                buffg.drawImage(resized_Effect_img, ex.x+50, ex.y, this);              
            }      
   }
   public void Draw_Status_Text(){
       if(player_Hitpoint == 0){
           buffg.setFont(new Font("Default",Font.BOLD,40));
           buffg.setColor(Color.black);
           buffg.drawString("TOTAL SCORE : " + game_Score,20 ,520);
           return;
       }
       buffg.setFont(new Font("Default",Font.BOLD,20));
       buffg.setColor(Color.white);
       
       buffg.drawString("SCORE : " + game_Score, f_width-150, 60);
       buffg.drawString("LIFE : " + player_Hitpoint, f_width-150, 80);
   }
   
   public void Draw_Char(){ //실제로 그림을 그릴 부분
       if(player_Hitpoint == 0){
           return;
       }
       buffg.drawImage(resized_me_img, x, y, this); //x,y가 계속 변함
       
   }
   public void Draw_Missile(){ // 미사일을 그리는 메소드. 이경우에는 멀리있는 미사일부터 그리게 된다. 처음 그린게 가장 멀리 가므로,
       if(player_Hitpoint == 0){
           return;
       }
       for(int i=0 ; i< Missile_List.size() ; ++i){
           //미사일 존재 유무를 확인
           ms = (Missile)(Missile_List.get(i)); //미사일 위치값 확인
           
           if(ms.who ==0)
                buffg.drawImage(resised_Missile_img, ms.x+90, ms.y+50, this ); //모든 미사일을 그릴때 +90,+50된 위치에서 그리는것.
           //현재 좌표에 미사일 그리기
           //아미지 크기를 감안한 미사일 발사 좌표는 수정됨.
           else
               buffg.drawImage(resized_Missile2_img, ms.x, ms.y, this);
       }
   }
   
   public void Draw_Enemy(){ //적 이미지를 그리는 부분
       if(player_Hitpoint == 0){
           return;
       }
       for(int i=0 ; i< Enemy_List.size() ; ++i){
           en = (Enemy)(Enemy_List.get(i));
           buffg.drawImage(resized_Enemy_img, en.x, en.y, this);
       }
   }
   
    public void keyPressed(KeyEvent e){ //키보드키를 눌렀을때 실행되는 함수
        switch(e.getKeyCode()){
            case KeyEvent.VK_UP : //VK는 문자가 아닌 가상키를 가리킴
                KeyUP = true;
                break;
             case KeyEvent.VK_DOWN :
                KeyDown = true;
                break;
             case KeyEvent.VK_LEFT :
                KeyLeft = true;
                break;
             case KeyEvent.VK_RIGHT :
                KeyRight = true;
                break;
                 
             case KeyEvent.VK_SPACE :
                 KeySpace = true;
                 break;
        }
    }
    
    public void keyReleased(KeyEvent e){ //키를 땠을 때 실행되는 함수
        //키보드가 떼어졌을때
        switch(e.getKeyCode()){
            case KeyEvent.VK_UP :
                KeyUP = false;
                break;
             case KeyEvent.VK_DOWN :
                KeyDown = false;
                break;
             case KeyEvent.VK_LEFT :
                KeyLeft = false;
                break;
             case KeyEvent.VK_RIGHT :
                KeyRight = false;
                break;
                 
             case KeyEvent.VK_SPACE:
                 KeySpace = false;
                 break;
        }
    }
    public void keyTyped(KeyEvent e){} //키보드가 타이핑될때   
    public void keyProcess(){ //pressed -> process 
        //키 입력시마다 5만큼 이동       
        if(KeyUP ==true && y>=33) y-=10;
        if(KeyDown ==true && y<=f_height-100) y+=10;
        if(KeyLeft ==true && x>=0) x-=10;
        if(KeyRight ==true && x<=f_width-100) x+=10;
    }
}




