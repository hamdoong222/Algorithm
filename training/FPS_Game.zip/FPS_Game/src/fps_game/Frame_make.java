
package fps_game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.image.*; //버퍼이미지 사용을 위한 임포트 추가
import java.io.File;
import javax.imageio.*;
import java.util.*; //ArrayList를 위한 임포트 추가.
import java.io.*; //파일 클래스 사용을 위한 임포트 추가


public class Frame_make {

    public static void main(String[] args) {
        Frame_make_sub fms = new Frame_make_sub();
    }
}
